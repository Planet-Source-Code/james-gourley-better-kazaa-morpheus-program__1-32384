-=- Read Me -=-... important for downloading.

Don't delete the DownloadFile.kmd.... if you do, or don't trust it, u can open Download.vbp in Visual Basic, and compile it to an exe file after reading the coding, then rename it to DownloadFile.kmd... this file is what the main project looks for to download a file. I decided to make the files separate so that, if for some reason, the main program freezes, which it tends to do from time to time, your downloads will not stop since they are running separate from the main project.

Also, extract this to the same directory as the main project... (as you can see it isn't too organized, which is why i haven't posted it on Planet Source Code yet)